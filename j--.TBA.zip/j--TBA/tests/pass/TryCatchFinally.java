/**
 * 
 */
package pass;


public class TryCatchFinally {
	public void tryCatchMethod() {
		try {
			
		} catch (Exception e) {
			
		} finally {
			
		}
	}
}
