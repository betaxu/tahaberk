package pass;
import java.lang.System;

public class BitwiseAnd {
	
    public static void main(String[] args) {
    	int a = 2;
    	int b = 1;
    	int c = a&b;
    	System.out.println("2 & 1 = " + c);
    }
    
    public int and(int x, int y) {

	return x & y;
    }
}
