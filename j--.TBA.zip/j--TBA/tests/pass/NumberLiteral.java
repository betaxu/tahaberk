package pass;

public class NumberLiteral {
	
	public NumberLiteral() {
		int decimal = 91;
//		int oct = 0712;
//		int hex = 0xF;
		int binary = 0b01000011110;
		long longNumber = 10L;
		float floatNumber = 0.25f;
		double doubleNumber = 0.2d;
		float f1 = .10f;
		double d1 = .5;
		float f2 = 1000.0005f;
		double d2 = 10000.005;
	}
}
