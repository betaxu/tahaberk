import java.util.concurrent.locks.Condition;

public class BreakTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
break;

	}

}
