import java.lang.System;
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		if (elsePart != null) {
	           System.out.println(0);
		 }else 
			 System.out.println(1);
		
		double[] i3 = { 1.1, 2.2, 3.2};
		int[] ia = { 1, 2, 3};
		int[][] iaa2 = { { 1, 2, 3 }, { 1, 2, 3, 4 } };

		int a = 2;
    	int b = 1;
    	int c = a|b;
    	a+=3;
    	a/=4;
    	for(int i=1 ;i>0;i++){
    		}
    		
    		
    	System.out.println(a||b);
	}
	
 	
}
