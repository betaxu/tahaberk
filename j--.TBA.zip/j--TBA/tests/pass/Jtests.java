
public class Jtests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] ia = { 1, 2, 3};
		int[][] iaa2 = { { 1.11, 2.2, 3 }, { 1, 2, 3, 4 }, {} };
		
		int a = 2;
    	int b = 1;
    	int c = a|b;
    	System.out.println("2 | 1 = " + c);
    	for(int i=1 ;i>0;i++){
    		System.out.println(i);
    	}
    		
    	
	}

}
