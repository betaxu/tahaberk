package pass;
import java.lang.System;

public class BitwiseXOr {
	
    public static void main(String[] args) {
    	int a = 5;
    	int b = 1;
    	int c = a ^ b;
    	System.out.println("5 ^ 1 = " + c);
    }
    
    public int xor(int x, int y) {

	return x ^ y;
    }
}
