package pass;
import java.lang.System;

public class BitwiseIOr {
	
    public static void main(String[] args) {
    	int a = 2;
    	int b = 1;
    	int c = a|b;
    	System.out.println("2 | 1 = " + c);
    }
    
    public int ior(int x, int y) {

	return x | y;
    }
}
