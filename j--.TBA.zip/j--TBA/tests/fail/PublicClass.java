package fail;

class PublicClass {

}

public class ExampleClass {
	
}