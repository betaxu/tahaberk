﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiFaceRec
{
    public partial class Log_in_page : Form //Login sayfası 
    {
        public Log_in_page()
        {
            InitializeComponent();
        }

        private void Btn_lgn_Click(object sender, EventArgs e)
        {
            User_information user = new User_information();
            bool record = user.verification(txt_name.Text, txt_pswrd.Text);
            if (record == true)
            {
                this.Hide();
                Face_recognize frm = new Face_recognize();
                frm.Show();
            }

            else
            {

                Log_in_page frm1 = new Log_in_page();
                lbl_message.Text = "There is no such password or username ";

            }
        }

        private void Log_in_page_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            User_information user = new User_information();
            if (user.changePassword(txt_name.Text, txt_pswrd.Text))
            {
                MessageBox.Show("Şifre Başarılı bir şekilde değiştirilmiştir.");
            }
            else
            {
                MessageBox.Show("Şifre değişimi sırasında hata olmuuştur");
            }
        }

    }
}
