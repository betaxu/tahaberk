﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MultiFaceRec
{
    public class User_information
    {
        public static user Id;
        public string publicSalt = "facelib";

        public bool verification(string name, string pswrd)
        {
            string password = this.HashPassword(this.publicSalt, pswrd);
            String Baglanti = "Server=.;Initial catalog=facelib;Integrated Security=True;";
            SqlConnection con = new SqlConnection(Baglanti);
            con.Open();
            string sqldata = "select Admin_Id,Admin_username,Admin_password from Admins_Login where Admin_username=@Admin_username and Admin_password=@Admin_password";
            SqlCommand cmd = new SqlCommand(sqldata, con);

            cmd.Parameters.AddWithValue("@Admin_username", name);
            cmd.Parameters.AddWithValue("@Admin_password", password);

            //cmd.CommandType = System.Data.CommandType.TableDirect;

            SqlDataReader dr = cmd.ExecuteReader();


            while (dr.Read())
            {
                name = dr["Admin_username"].ToString();
                pswrd = dr["Admin_password"].ToString();

                Id = new user();
                Id.Admin_Id = Convert.ToInt32(dr["Admin_Id"].ToString());


            }
            if (dr.HasRows == true)
            {

                con.Close();
                cmd.Dispose();
                return true;
            }
            else
            {
                return false;

            }
        }

        public bool changePassword(string name, string pswrd)
        {
            string password = this.HashPassword(this.publicSalt, pswrd);
            String Baglanti = "Server=.;Initial catalog=facelib;Integrated Security=True;";
            SqlConnection con = new SqlConnection(Baglanti);
            con.Open();
            string sqldata = "update Admins_Login set Admin_password=@Admin_password  where Admin_username=@Admin_username";
            SqlCommand cmd = new SqlCommand(sqldata, con);

            cmd.Parameters.AddWithValue("@Admin_username", name);
            cmd.Parameters.AddWithValue("@Admin_password", password);
            bool control = false;
            try
            {
                if(cmd.ExecuteNonQuery()>0)
                { 
                control = true;
                }
            }
            catch
            {

            }
            return control;
        }

        public string HashPassword(string salt, string password)
        {
            return Sha256Hex(salt + password);
        }

        private static string Sha256Hex(string toHash)
        {
            SHA256Managed hash = new SHA256Managed();
            byte[] utf8 = UTF8Encoding.UTF8.GetBytes(toHash);
            return BytesToHex(hash.ComputeHash(utf8));
        }

        private static string BytesToHex(byte[] toConvert)
        {
            StringBuilder s = new StringBuilder(toConvert.Length * 2);
            foreach (byte b in toConvert)
            {
                s.Append(b.ToString("x2"));
            }
            return s.ToString();
        }
    }
}
