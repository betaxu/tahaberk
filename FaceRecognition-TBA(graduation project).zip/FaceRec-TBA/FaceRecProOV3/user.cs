﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiFaceRec
{
   public class user
    {
        public int Admin_Id { get; set; }

    }
}
