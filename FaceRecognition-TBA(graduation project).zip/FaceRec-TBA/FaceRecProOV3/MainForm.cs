﻿


using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.IO;
using System.Diagnostics;

namespace MultiFaceRec
{
    public partial class Face_recognize : Form
    {
        //Bütün değişkenlerin, vektörlerin ve haarcascade'in tanımı
        Image<Bgr, Byte> currentFrame;
        Capture grabber; //
        HaarCascade face;
        HaarCascade eye;
        MCvFont font = new MCvFont(FONT.CV_FONT_HERSHEY_TRIPLEX, 0.5d, 0.5d); //Belirli bir tür,  Yazı Tipi Oluşturma
        Image<Gray, byte> result, TrainedFace = null;
        Image<Gray, byte> gray = null;
        List<Image<Gray, byte>> trainingImages = new List<Image<Gray, byte>>();
        List<string> labels = new List<string>();
        List<string> knownperson = new List<string>();
        int ContTrain, NumLabels, t;
        string name, names = null;

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void imageBoxFrameGrabber_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        public Face_recognize()
        {
            InitializeComponent();
            //Yüz algılama için haarcascade yükleme
            face = new HaarCascade("haarcascade_frontalface_default.xml");

            try
            {
                // Her bir resim için önceden hazırlanmış trainedface'lerin ve labellerin yüklenmesi
                string Labelsinfo = File.ReadAllText(Application.StartupPath + "/RecognizedFaces/Added_name.txt");
                string[] Labels = Labelsinfo.Split('%');
                NumLabels = Convert.ToInt16(Labels[0]);
                ContTrain = NumLabels;
                string LoadFaces;

                for (int tf = 1; tf < NumLabels + 1; tf++) //text içine faceleri numaralarla ekleme
                {
                    LoadFaces = "face" + tf + ".bmp";
                    trainingImages.Add(new Image<Gray, byte>(Application.StartupPath + "/RecognizedFaces/" + LoadFaces)); //Griye çevir dosyaya ekle
                    labels.Add(Labels[tf]);
                }

            }
            catch (Exception e)
            {


                MessageBox.Show("Nothing in database.", "Triained faces load", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }





        private void button1_Click(object sender, EventArgs e) //Start butonu 
        {
            //capture device'ı başlat 
            grabber = new Capture();
            grabber.QueryFrame();
            // FrameGraber event'i başlat(video akışından bireysel ya da sabit çerçeveyi yakalamak için)
            Application.Idle += new EventHandler(FrameGrabber);
            btn_det_rec.Enabled = false;
        }


        private void button2_Click(object sender, System.EventArgs e)
        {
            try
            {
                //Trained face sayacı
                ContTrain = ContTrain + 1;

                //capture device yardımıyla gri çerçeveler alma
                gray = grabber.QueryGrayFrame().Resize(320, 240, Emgu.CV.CvEnum.INTER.CV_INTER_CUBIC);

                //yüz algılama
                MCvAvgComp[][] facesDetected = gray.DetectHaarCascade(
                face,
                1.2,
                10,
                Emgu.CV.CvEnum.HAAR_DETECTION_TYPE.DO_CANNY_PRUNING,
                new Size(20, 20));
               
            
                //Algılanan her öge için aksiyon 
                foreach (MCvAvgComp f in facesDetected[0])
                {
                    currentFrame.Draw(f.rect, new Bgr(Color.Red), 2);
                    TrainedFace = currentFrame.Copy(f.rect).Convert<Gray, byte>();
                    break;
                }

                //resize,yüzün algılanmış görüntüsü ile aynı boyutu karşılaştırmak için
                //görüntüyü cubic interpolation metoduyla test etme
                TrainedFace = result.Resize(100, 100, Emgu.CV.CvEnum.INTER.CV_INTER_CUBIC);
                trainingImages.Add(TrainedFace);
                labels.Add(textBox1.Text);

                //Eklenen gri resmi gösterme
                imageBox1.Image = TrainedFace;

                // ileriki yüklemeler için triained face lerin numarasını text içine yazma
                File.WriteAllText(Application.StartupPath + "/RecognizedFaces/Added_name.txt", trainingImages.ToArray().Length.ToString() + "%");

                //İleriki yüklemeler için trained face lerin labellerini(etiket) text içine yazma
                for (int i = 1; i < trainingImages.ToArray().Length + 1; i++)
                {
                    trainingImages.ToArray()[i - 1].Save(Application.StartupPath + "/RecognizedFaces/face" + i + ".bmp");
                    File.AppendAllText(Application.StartupPath + "/RecognizedFaces/Added_name.txt", labels.ToArray()[i - 1] + "%");
                }

                MessageBox.Show(textBox1.Text + "´s face detected and added ", "Training OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Enable the face detection first", "Training Fail", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }


        void FrameGrabber(object sender, EventArgs e)
        {
            label3.Text = "0";
            //label4.Text = "";
            knownperson.Add("");


            // Capture device içinden Current frame yakalama
            currentFrame = grabber.QueryFrame().Resize(320, 240, Emgu.CV.CvEnum.INTER.CV_INTER_CUBIC);

            // Gri ölçeğe dönüştürme
            gray = currentFrame.Convert<Gray, Byte>();

            //Yüz algılayıcı
            MCvAvgComp[][] facesDetected = gray.DetectHaarCascade(
          face,
          1.2,
          10,
          Emgu.CV.CvEnum.HAAR_DETECTION_TYPE.DO_CANNY_PRUNING,
          new Size(20, 20));

            //Algılanan her öge için aksiyon 
            foreach (MCvAvgComp f in facesDetected[0])
            {
                t = t + 1;
               
                result = currentFrame.Copy(f.rect).Convert<Gray, byte>().Resize(100, 100, Emgu.CV.CvEnum.INTER.CV_INTER_CUBIC);
                
                // 0'ıncı (gri) kanalda tespit edilen yüzü mavi renkle çizin


                if (trainingImages.ToArray().Length != 0)
                {
                    // TermCriteria,  trained face sayısıyla yüz tanıma (maxIteration gibi )
                    MCvTermCriteria termCrit = new MCvTermCriteria(ContTrain, 0.001);

                    //Eigen face tanıyıcı

                    EigenObjectRecognizer recognizer = new EigenObjectRecognizer(
                       trainingImages.ToArray(),
                       labels.ToArray(),
                       3000,
                       ref termCrit);
                    
                    name = recognizer.Recognize(result);

                    if (name == "")
                    {
                        currentFrame.Draw(f.rect, new Bgr(Color.Red), 2);
                    }
                    else {
                       
                        currentFrame.Draw(name, ref font, new Point(f.rect.X - 2, f.rect.Y - 2), new Bgr(Color.LightGreen));
                        currentFrame.Draw(f.rect, new Bgr(Color.Blue), 2);
                    }

                    //  Algılanan ve tanınan her yüz için label çizme






                }







                knownperson[t - 1] = name;
               
                knownperson.Add("");

                //Set the number of faces detected on the scene
                label3.Text = facesDetected[0].Length.ToString();



            }
            t = 0;

            //Names concatenation of persons recognized
            for (int nnn = 0; nnn < facesDetected[0].Length; nnn++)
            {
                names = names + knownperson[nnn] + ", ";

                //Show the faces procesed and recognized





            }
            imageBoxFrameGrabber.Image = currentFrame;

        }
    }
}