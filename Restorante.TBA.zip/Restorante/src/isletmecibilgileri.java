import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.TextField;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;

public class isletmecibilgileri extends JFrame {

	private JPanel contentPane;
	private TextField textField;
	private TextField textField_1;
	private TextField textField_2;
	private TextField textField_3;
	private TextField textField_4;
	private TextField textField_5;
	private TextField textField_6;

	
	public void ekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/javap","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO javap(kullanad, soyad, numara,mail,adres, girisismi, sifre) VALUES (?,?,?,?,?,?,?)");
			
		    uygula.setString( 1, textField.getText() );
		    uygula.setString( 2, textField_1.getText() );
		    uygula.setString( 3,textField_2.getText() );
		    uygula.setString( 4, textField_3.getText() );
		    uygula.setString( 5, textField_4.getText() );
		    uygula.setString( 6, textField_5.getText() );
		    uygula.setString( 7, textField_6.getText() );
		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}
	
	public void gekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmebilgileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO isletmebilgileri (girisismi) VALUES (?)");
			
		  
		    uygula.setString( 1, textField_5.getText() );
		    
		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "giriş bilgileri güncellendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					isletmecibilgileri frame = new isletmecibilgileri();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public isletmecibilgileri() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 662, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u0130\u015ELETMEC\u0130 B\u0130LG\u0130LER\u0130");
		label.setFont(new Font("Tahoma", Font.BOLD, 19));
		label.setBounds(185, 53, 275, 28);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u0130\u015Fletme  Sahibinin Ad\u0131  ve Soyad\u0131 \r\n");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_1.setBounds(71, 134, 198, 14);
		contentPane.add(label_1);
		
		textField = new TextField();
		textField.setText(" ");
		textField.setBounds(299, 134, 117, 23);
		contentPane.add(textField);
		
		textField_1 = new TextField();
		textField_1.setText(" ");
		textField_1.setBounds(444, 134, 126, 23);
		contentPane.add(textField_1);
		
		textField_2 = new TextField();
		textField_2.setText(" ");
		textField_2.setBounds(299, 176, 275, 23);
		contentPane.add(textField_2);
		
		JMenuItem menuItem = new JMenuItem("Numara ");
		menuItem.setBounds(40, 177, 85, 22);
		contentPane.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("Mail");
		menuItem_1.setBounds(40, 224, 91, 22);
		contentPane.add(menuItem_1);
		
		textField_3 = new TextField();
		textField_3.setText(" ");
		textField_3.setBounds(299, 223, 275, 23);
		contentPane.add(textField_3);
		
		textField_4 = new TextField();
		textField_4.setText(" ");
		textField_4.setBounds(299, 274, 275, 23);
		contentPane.add(textField_4);
		
		JMenuItem menuItem_2 = new JMenuItem("Adres");
		menuItem_2.setBounds(40, 272, 103, 25);
		contentPane.add(menuItem_2);
		
		JMenuItem menuItem_3 = new JMenuItem("Kullan\u0131c\u0131 Ad\u0131");
		menuItem_3.setBounds(36, 362, 131, 22);
		contentPane.add(menuItem_3);
		
		textField_5 = new TextField();
		textField_5.setText(" ");
		textField_5.setBounds(295, 362, 275, 23);
		contentPane.add(textField_5);
		
		textField_6 = new TextField();
		textField_6.setText(" ");
		textField_6.setBounds(295, 395, 275, 23);
		contentPane.add(textField_6);
		
		JMenuItem menuItem_4 = new JMenuItem("\u015Eifre");
		menuItem_4.setBounds(36, 396, 103, 22);
		contentPane.add(menuItem_4);
		
		JButton button = new JButton("Devam");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
		 isletmebilgileri frame = new isletmebilgileri ();
	   	 frame.setVisible(true);
				   
	   	 ekle();
	   	 gekle();
	   	 dispose();

				
			}
		});
		button.setBounds(461, 531, 109, 30);
		contentPane.add(button);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(6, 104, 564, 1);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(6, 459, 564, 1);
		contentPane.add(separator_1);
		
		JLabel label_2 = new JLabel("Eger kutuyu isaretledikten sonra devam butonunu tikladiginizda bilgileriniz kayit edilecektir.Lutfen bilgilerinizi kontrol ediniz");
		label_2.setBounds(16, 465, 603, 29);
		contentPane.add(label_2);
		
		JCheckBox checkBox = new JCheckBox("  Bilgilerimin dogrulugunu onayliyorum.");
		checkBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
			if(checkBox.isSelected()){
				
				button.setVisible(true);

			}
			else{
				
				button.setVisible(false);

			}
			}
		});
		
		
		
		
		checkBox.setBounds(6, 501, 504, 23);
		contentPane.add(checkBox);
	}
}
