import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import javax.swing.JTextArea;
import java.awt.TextField;
import java.awt.dnd.MouseDragGestureRecognizer;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.Scrollbar;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.List;
import java.awt.ScrollPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JSlider;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Event;

import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.ProgressBarUI;
import javax.swing.plaf.SliderUI;
import javax.swing.border.CompoundBorder;
import javax.swing.JSpinner;
import java.awt.Label;
import java.awt.SystemColor;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bilgiguncelleENG extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldacik;
	private JTextField textField_1kapali;
	private JComboBox yasbox;
	private JSlider sliderkızerkek;
	private JProgressBar progressBar;
	private JComboBox timeboxsiparis;
	private JSlider slider_1ses;

	
	public void ekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmebilgileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO isletmebilgilerieng(yogunlukacik , yogunlukkapali,  yas , kizerkek, siparissre,ses ) VALUES (?,?,?,?,?,?)");
			
			 uygula.setString( 1,textFieldacik.getText() );
			    uygula.setString( 2,textField_1kapali.getText() );
			    uygula.setString( 3,yasbox.getSelectedItem().toString() );
			 
				uygula.setObject(4, sliderkızerkek.getValue());
				uygula.setObject(5, timeboxsiparis.getSelectedItem().toString());

					  
				uygula.setObject(6, slider_1ses.getValue());

		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
		public void guncelle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmebilgileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("UPDATE isletmebilgilerieng SET kizerkek=[?-1],ses=[?-2],siparissre=[?-3],yas=[?-4],yogunlukacik=[?-5],yogunlukkapali=[?-6] WHERE 1");
			uygula.setObject(1, sliderkızerkek.getValue());
							uygula.setObject(2, slider_1ses.getValue());
				uygula.setObject(3, timeboxsiparis.getSelectedItem().toString());
			    uygula.setString( 4,yasbox.getSelectedItem().toString() );
					   uygula.setString( 5,textFieldacik.getText() );

			    uygula.setString( 6,textField_1kapali.getText() );
			 
				


		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bilgiguncelleENG frame = new bilgiguncelleENG();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bilgiguncelleENG() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 801);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Age Range of Consumer     *");
		lblNewLabel.setBounds(42, 273, 154, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Man and Woman Ratio of Place    (optional)\r\n");
		lblNewLabel_1.setBounds(42, 348, 232, 46);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Order Time   *\r\n");
		lblNewLabel_2.setBounds(42, 487, 130, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewJgoodiesLabel = DefaultComponentFactory.getInstance().createLabel("Density (Number od Desks)     *");
		lblNewJgoodiesLabel.setBounds(42, 124, 208, 14);
		contentPane.add(lblNewJgoodiesLabel);
		
		JLabel lblSesArall = new JLabel("Place Voice Range     *");
		lblSesArall.setBounds(42, 570, 130, 14);
		contentPane.add(lblSesArall);
		
		timeboxsiparis = new JComboBox();
		timeboxsiparis.setModel(new DefaultComboBoxModel(new String[] {"5 min", "10 min", "15 min", "20 min", "25 min", "30 min", "35 min", "40 min ", "45 min", "50 min", "55 min", "1 hour", "1 hour or over"}));
		timeboxsiparis.setToolTipText("5 dk");
		timeboxsiparis.setBounds(351, 484, 123, 20);
		contentPane.add(timeboxsiparis);
		
		textFieldacik = new JTextField();
		textFieldacik.setBounds(351, 121, 86, 20);
		contentPane.add(textFieldacik);
		textFieldacik.setColumns(10);
		
		textField_1kapali = new JTextField();
		textField_1kapali.setColumns(10);
		textField_1kapali.setBounds(543, 121, 86, 20);
		contentPane.add(textField_1kapali);
		
		yasbox = new JComboBox();
		yasbox.setModel(new DefaultComboBoxModel(new String[] {"18+", "21+", "Middle Age or Over", "General"}));
		yasbox.setToolTipText("");
		yasbox.setBounds(351, 270, 123, 20);
		contentPane.add(yasbox);
		
		JLabel lblNewLabel_3 = new JLabel("Open");
		lblNewLabel_3.setBounds(377, 97, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblKapal = new JLabel("Closed");
		lblKapal.setBounds(570, 96, 46, 14);
		contentPane.add(lblKapal);
		
		JSlider slider_2 = new JSlider();
		slider_2.setToolTipText(" ");
		slider_2.setSnapToTicks(true);
		slider_2.setPaintTicks(true);
		slider_2.setPaintLabels(true);
		slider_2.setMajorTickSpacing(10);
		slider_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		slider_2.setBorder(UIManager.getBorder("DesktopIcon.border"));
		slider_2.setBounds(351, 178, 276, 46);
		contentPane.add(slider_2);
		
		slider_1ses = new JSlider();
		slider_1ses.setBorder(new TitledBorder(new TitledBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "High Voice", TitledBorder.RIGHT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)), "Normal", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(0, 0, 0)), "Quiet", TitledBorder.LEFT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)));
		slider_1ses.setToolTipText("\r\n");
		slider_1ses.setSnapToTicks(true);
		slider_1ses.setPaintTicks(true);
		slider_1ses.setPaintLabels(true);
		slider_1ses.setMajorTickSpacing(25);
		slider_1ses.setFont(new Font("Tahoma", Font.PLAIN, 11));
		slider_1ses.setBounds(353, 527, 276, 85);
		contentPane.add(slider_1ses);
		
		progressBar = new JProgressBar();
		progressBar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		progressBar.setForeground(new Color(0, 128, 0));
		progressBar.setBackground(Color.WHITE);
		progressBar.setStringPainted(true);
		progressBar.setBounds(353, 389, 276, 24);
		contentPane.add(progressBar);
		
		sliderkızerkek = new JSlider();
		sliderkızerkek.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
		
			int x = sliderkızerkek.getValue();
			progressBar.setValue(x);
			
			}
		});
		sliderkızerkek.setToolTipText(" ");
		sliderkızerkek.setSnapToTicks(true);
		sliderkızerkek.setPaintTicks(true);
		sliderkızerkek.setPaintLabels(true);
		sliderkızerkek.setMajorTickSpacing(10);
		sliderkızerkek.setFont(new Font("Tahoma", Font.PLAIN, 11));
		sliderkızerkek.setBorder(new TitledBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Woman", TitledBorder.RIGHT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)), "", TitledBorder.LEFT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)));
		sliderkızerkek.setBounds(353, 335, 276, 55);
		contentPane.add(sliderkızerkek);
		
		Label label = new Label("RESTAURANT");
		label.setForeground(SystemColor.inactiveCaptionBorder);
		label.setFont(new Font("Andalus", Font.BOLD, 31));
		label.setBackground(Color.LIGHT_GRAY);
		label.setBounds(351, 10, 219, 43);
		contentPane.add(label);
		
		
		
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if(btnUpdate.isSelected()){
					
                    guncelle();
				
					btnUpdate.setVisible(true);
					
					
				}
			}
		});
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnUpdate.setVisible(false);
			
			}
		});
		
		btnUpdate.setBounds(10, 701, 764, 38);
		contentPane.add(btnUpdate);
		
		JButton button = new JButton("UPDATE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(button.getAncestorListeners() != null){
				
                ekle();
				
			    button.setVisible(false);
				btnUpdate.setVisible(true);
				

				
			}
			else{
				
				btnUpdate.setVisible(false);

			}
			}
		});
		

	
		
			
		button.setBounds(10, 662, 764, 38);
		contentPane.add(button);
		
		
		
	
			
			
				}
	}

