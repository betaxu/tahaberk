import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import javax.swing.JTextArea;
import java.awt.TextField;
import java.awt.dnd.MouseDragGestureRecognizer;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.Scrollbar;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.List;
import java.awt.ScrollPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JSlider;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Event;

import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.ProgressBarUI;
import javax.swing.plaf.SliderUI;
import javax.swing.border.CompoundBorder;
import javax.swing.JSpinner;
import java.awt.Label;
import java.awt.SystemColor;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionEvent;

public class bilgiguncelleTR extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldacık;
	private JTextField textField_1kapalı;
	private JSlider slider_1;
	private JComboBox yasbox;
	private JSlider sliderkızerkek;
	private JProgressBar progressBar;
	private JComboBox comboBoxsiparis;
	private JSlider slider_2ses;
	private JButton button_1;


	
	public void ekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmebilgileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO isletmebilgileri( yogunlukacik , yogunlukkapali,  yas , kizerkek, siparissre,ses ) VALUES (?,?,?,?,?,?)");
			
		    uygula.setString( 1,textFieldacık.getText() );
		    uygula.setString( 2,textField_1kapalı.getText() );
		    uygula.setString( 3,yasbox.getSelectedItem().toString() );
		 
			uygula.setObject(4, sliderkızerkek.getValue());
			uygula.setObject(5, comboBoxsiparis.getSelectedItem().toString());

				  
			uygula.setObject(6, slider_2ses.getValue());

		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
	public void guncelle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmebilgileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("UPDATE isletmebilgileri SET  kizerkek=? , ses=? ,siparissre=? ,yas=? ,yogunlukacik=? ,yogunlukkapali=? WHERE girisismi = ?");
			uygula.setObject(1, sliderkızerkek.getValue());
			uygula.setObject(2, slider_2ses.getValue());
			uygula.setObject(3, comboBoxsiparis.getSelectedItem().toString());
		    uygula.setString( 4,yasbox.getSelectedItem().toString() );
		    uygula.setString( 5,textFieldacık.getText() );
		    uygula.setString( 6,textField_1kapalı.getText() );
			uygula.setString( 7,giris.getText() );

		 

		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
	
	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bilgiguncelleTR frame = new bilgiguncelleTR();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public  bilgiguncelleTR() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 797);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("M\u00DC\u015ETER\u0130 YA\u015E ARALI\u011EI     *");
		lblNewLabel.setBounds(42, 273, 154, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("MEKANDAK\u0130 KIZ-ERKEK ORANI     (opsiyonel )\r\n");
		lblNewLabel_1.setBounds(42, 348, 232, 46);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("S\u0130PAR\u0130\u015E S\u00DCRES\u0130     *\r\n");
		lblNewLabel_2.setBounds(42, 487, 130, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewJgoodiesLabel = DefaultComponentFactory.getInstance().createLabel("YO\u011EUNLUK (MASA SAYISI)     *");
		lblNewJgoodiesLabel.setBounds(42, 124, 208, 14);
		contentPane.add(lblNewJgoodiesLabel);
		
		JLabel lblSesArall = new JLabel("MEKAN SES ARALI\u011EI     *");
		lblSesArall.setBounds(42, 570, 130, 14);
		contentPane.add(lblSesArall);
		
		comboBoxsiparis = new JComboBox();
		comboBoxsiparis.setModel(new DefaultComboBoxModel(new String[] {"5 dk", "10 dk", "15 dk", "20 dk", "25 dk ", "30 dk", "35 dk", "40 dk ", "45 dk", "50 dk", "55 dk", "1 saat ", "1 saat veya \u00FCzeri"}));
		comboBoxsiparis.setToolTipText("5 dk");
		comboBoxsiparis.setBounds(351, 484, 123, 20);
		contentPane.add(comboBoxsiparis);
		
		textFieldacık = new JTextField();
		textFieldacık.setBounds(351, 121, 86, 20);
		contentPane.add(textFieldacık);
		textFieldacık.setColumns(10);
		
		textField_1kapalı = new JTextField();
		textField_1kapalı.setColumns(10);
		textField_1kapalı.setBounds(543, 121, 86, 20);
		contentPane.add(textField_1kapalı);
		
		yasbox = new JComboBox();
		yasbox.setModel(new DefaultComboBoxModel(new String[] {"18+", "21+", "Orta Yas ve Üstü", "Genel"}));
		yasbox.setToolTipText("");
		yasbox.setBounds(351, 270, 123, 20);
		contentPane.add(yasbox);
		
		JLabel lblNewLabel_3 = new JLabel("A\u00E7\u0131k");
		lblNewLabel_3.setBounds(377, 97, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblKapal = new JLabel("Kapal\u0131");
		lblKapal.setBounds(570, 96, 46, 14);
		contentPane.add(lblKapal);
		
		slider_1 = new JSlider();
		slider_1.setToolTipText(" ");
		slider_1.setSnapToTicks(true);
		slider_1.setPaintTicks(true);
		slider_1.setPaintLabels(true);
		slider_1.setMajorTickSpacing(10);
		slider_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		slider_1.setBorder(UIManager.getBorder("DesktopIcon.border"));
		slider_1.setBounds(351, 178, 276, 46);
		contentPane.add(slider_1);
		
		slider_2ses = new JSlider();
		slider_2ses.setBorder(new TitledBorder(new TitledBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Y\u00FCksek Ses ", TitledBorder.RIGHT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)), "Normal", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(0, 0, 0)), "Sessiz", TitledBorder.LEFT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)));
		slider_2ses.setToolTipText("\r\n");
		slider_2ses.setSnapToTicks(true);
		slider_2ses.setPaintTicks(true);
		slider_2ses.setPaintLabels(true);
		slider_2ses.setMajorTickSpacing(25);
		slider_2ses.setFont(new Font("Tahoma", Font.PLAIN, 11));
		slider_2ses.setBounds(353, 527, 276, 85);
		contentPane.add(slider_2ses);
		
		progressBar = new JProgressBar();
		progressBar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		progressBar.setForeground(new Color(0, 128, 0));
		progressBar.setBackground(Color.WHITE);
		progressBar.setStringPainted(true);
		progressBar.setBounds(353, 389, 276, 24);
		contentPane.add(progressBar);
		
		sliderkızerkek = new JSlider();
		sliderkızerkek.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
		
			int x = sliderkızerkek.getValue();
			progressBar.setValue(x);
			
			}
		});
		sliderkızerkek.setToolTipText(" ");
		sliderkızerkek.setSnapToTicks(true);
		sliderkızerkek.setPaintTicks(true);
		sliderkızerkek.setPaintLabels(true);
		sliderkızerkek.setMajorTickSpacing(10);
		sliderkızerkek.setFont(new Font("Tahoma", Font.PLAIN, 11));
		sliderkızerkek.setBorder(new TitledBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "KIZ", TitledBorder.RIGHT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)), "", TitledBorder.LEFT, TitledBorder.BOTTOM, null, new Color(0, 0, 0)));
		sliderkızerkek.setBounds(353, 335, 276, 55);
		contentPane.add(sliderkızerkek);
		
		Label label = new Label("RESTORAN");
		label.setForeground(SystemColor.inactiveCaptionBorder);
		label.setFont(new Font("Andalus", Font.BOLD, 31));
		label.setBackground(Color.LIGHT_GRAY);
		label.setBounds(351, 10, 176, 43);
		contentPane.add(label);
		
		
		
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				   guncelle();	
			}
		});
		
		btnUpdate.setBounds(10, 701, 764, 38);
		contentPane.add(btnUpdate);
		
		btnUpdate.setVisible(false);

		
		JButton button = new JButton("UPDATE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
					if(button.getAncestorListeners() != null){
					
                    ekle();
					
				    button.setVisible(false);
					btnUpdate.setVisible(true);
					

					
				}
				else{
					
					btnUpdate.setVisible(false);

				}
				}
			});
			
	
		
			
		button.setBounds(10, 662, 764, 38);
		contentPane.add(button);
		
		
		
	
			
			
				}
	}

