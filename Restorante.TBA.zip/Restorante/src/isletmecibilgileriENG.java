import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.TextField;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JCheckBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class isletmecibilgileriENG extends JFrame {

	public JPanel contentPane;
	private TextField txtF;
	private TextField txtLast;
	private TextField txtNumber;
	private TextField txtMail;
	private TextField txtAdres;
	private TextField txtGrs;
	private TextField txtParola;

	public void ekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/javap","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO javapeng(kullanad, soyad, numara,mail,adres, girisismi, sifre) VALUES (?,?,?,?,?,?,?)");
			
		    uygula.setString( 1, txtF.getText() );
		    uygula.setString( 2, txtLast.getText() );
		    uygula.setString( 3, txtNumber.getText() );
		    uygula.setString( 4, txtMail.getText() );
		    uygula.setString( 5, txtAdres.getText() );
		    uygula.setString( 6, txtGrs.getText() );
		    uygula.setString( 7, txtParola.getText() );
		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
	
	
	public static void main(String[] args) {
		
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					isletmecibilgileriENG frame = new isletmecibilgileriENG();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public isletmecibilgileriENG() {
	
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 689, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBusnessAdmnstratorInformaton = new JLabel("BUSINESS ADMINISTRATOR INFORMATION");
		lblBusnessAdmnstratorInformaton.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblBusnessAdmnstratorInformaton.setBounds(94, 53, 434, 28);
		contentPane.add(lblBusnessAdmnstratorInformaton);
		
		JLabel lblAdministratorFirstAnd = new JLabel("Administrator First and Second Name");
		lblAdministratorFirstAnd.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAdministratorFirstAnd.setBounds(40, 134, 229, 14);
		contentPane.add(lblAdministratorFirstAnd);
		
		txtF = new TextField();
		txtF.setText(" ");
		txtF.setBounds(299, 134, 117, 23);
		contentPane.add(txtF);
		
		txtLast = new TextField();
		txtLast.setText(" ");
		txtLast.setBounds(444, 134, 126, 23);
		contentPane.add(txtLast);
		
		txtNumber = new TextField();
		txtNumber.setText(" ");
		txtNumber.setBounds(299, 176, 275, 23);
		contentPane.add(txtNumber);
		
		JMenuItem mnitmNumber = new JMenuItem("Number");
		mnitmNumber.setBounds(40, 177, 91, 22);
		contentPane.add(mnitmNumber);
		
		JMenuItem mnitmEmail = new JMenuItem("e-Mail");
		mnitmEmail.setBounds(40, 224, 91, 22);
		contentPane.add(mnitmEmail);
		
		txtMail = new TextField();
		txtMail.setText(" ");
		txtMail.setBounds(299, 223, 275, 23);
		contentPane.add(txtMail);
		
		txtAdres = new TextField();
		txtAdres.setText(" ");
		txtAdres.setBounds(299, 274, 275, 23);
		contentPane.add(txtAdres);
		
		JMenuItem mnitmAdress = new JMenuItem("Address");
		mnitmAdress.setBounds(40, 272, 103, 25);
		contentPane.add(mnitmAdress);
		
		JMenuItem mnitmLoginName = new JMenuItem("Login Name");
		mnitmLoginName.setBounds(36, 362, 131, 22);
		contentPane.add(mnitmLoginName);
		
		txtGrs = new TextField();
		txtGrs.setText(" ");
		txtGrs.setBounds(295, 362, 275, 23);
		contentPane.add(txtGrs);
		
		txtParola = new TextField();
		txtParola.setText(" ");
		txtParola.setBounds(295, 395, 275, 23);
		contentPane.add(txtParola);
		
		JMenuItem mnitmPassword = new JMenuItem("Password");
		mnitmPassword.setBounds(36, 396, 103, 22);
		contentPane.add(mnitmPassword);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(6, 104, 564, 1);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(6, 459, 564, 1);
		contentPane.add(separator_1);
		
		JLabel lblCreateNewLogin = new JLabel("Create new login name and password");
		lblCreateNewLogin.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCreateNewLogin.setBounds(66, 323, 434, 28);
		contentPane.add(lblCreateNewLogin);
		
		JButton btnNext = new JButton("Next");
		btnNext.setVisible(false);
		btnNext.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent arg0) {
		
		 isletmebilgilerENG frame = new  isletmebilgilerENG();
		 frame.setVisible(true);
		 dispose();	
		
			
			
			 ekle( );
	
		}
		});
			   
		btnNext.setBounds(461, 531, 109, 30);
		contentPane.add(btnNext);	
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("   I confirm my information.");
		chckbxNewCheckBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
			if(chckbxNewCheckBox.isSelected()){
				
				btnNext.setVisible(true);

			}
			else{
				
				btnNext.setVisible(false);

			}
			}
		});
		chckbxNewCheckBox.setBounds(66, 501, 504, 23);
		contentPane.add(chckbxNewCheckBox);
		
		
		
		
		JLabel lblIfYouMark = new JLabel("If you mark the check box , your informations are save .Please control self information.");
		lblIfYouMark.setBounds(67, 471, 503, 14);
		contentPane.add(lblIfYouMark);

	
	}	
	
	
}