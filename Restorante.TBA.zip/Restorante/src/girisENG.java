import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Canvas;
import java.awt.Label;
import javax.swing.JPasswordField;

public class girisENG extends JFrame {

	private JPanel contentPane;
	private JTextField txtAdmin;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					girisENG frame = new girisENG();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public girisENG() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		contentPane = new JPanel();
		contentPane.setForeground(UIManager.getColor("Button.background"));
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(23, 152, 561, -3);
		contentPane.add(separator);
		
		JLabel lblNewLabel = new JLabel("ADMIN");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel.setBounds(84, 183, 152, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1.setBounds(84, 255, 152, 34);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
			 
			 
			 String Username = txtAdmin.getText();
			
			String Password = passwordField.getText();			
			
			
			if(Password.contains("sa") && Username.contains("sa")) {
			
			bilgiguncelleENG in = new bilgiguncelleENG();
			in.main(null);
			 
			dispose();
			}
			else{
				
				JOptionPane.showMessageDialog(null, "invalid password or username ","Login Error",JOptionPane.ERROR_MESSAGE);
					
				txtAdmin.setText(null);	
				passwordField.setText(null);
			
			}
			}
		});
		btnNewButton.setBounds(254, 337, 108, 23);
		contentPane.add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		

				dispose();

			
			}
		});
		btnExit.setBounds(372, 337, 108, 23);
		contentPane.add(btnExit);
		
		txtAdmin = new JTextField();
		txtAdmin.setBounds(254, 194, 226, 20);
		contentPane.add(txtAdmin);
		txtAdmin.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(254, 266, 226, 20);
		contentPane.add(passwordField);
		passwordField.setColumns(10);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(23, 344, 561, -3);
		contentPane.add(separator_1);
		
		JButton btnNewButton_1 = new JButton("New User");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
			SozlesmeENG frame3 =new SozlesmeENG();
			frame3.setVisible(true);
			dispose();
			}
		});
		btnNewButton_1.setBounds(10, 438, 574, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnIForgetMy = new JButton("I forget my password !");
		btnIForgetMy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			JOptionPane.showMessageDialog(null, "�uanda servis d���");
			}
		});
		btnIForgetMy.setBounds(10, 472, 574, 23);
		contentPane.add(btnIForgetMy);
		
		Label label = new Label("RESTAURANT");
		label.setBackground(Color.BLACK);
		label.setFont(new Font("Andalus", Font.BOLD, 31));
		label.setBounds(199, 10, 219, 43);
		contentPane.add(label);
		
		JLabel lblLognSystem = new JLabel("LOGIN SYSTEM");
		lblLognSystem.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblLognSystem.setBounds(223, 90, 184, 34);
		contentPane.add(lblLognSystem);
		
		JButton btnTurkish = new JButton("TR");
		btnTurkish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				girisTR frame = new girisTR();
				frame.setVisible(true);
			
				dispose();
			}
		});
		btnTurkish.setBounds(10, 10, 69, 23);
		contentPane.add(btnTurkish);
		
		
	}
}
