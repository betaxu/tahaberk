import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import java.awt.TextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class isletmebilgileri extends JFrame {

	private JPanel contentPane;
	private JMenuItem MekanKapasitesikiiSays;
	private JMenuItem ToplamMasaSayskapal;
	private JMenuItem TtnrnlerininSerbest;
	private JMenuItem AlkapanSaati;
	private JMenuItem AlkolKullanm;
	private JMenuItem MekanTipi;
	private TextField textField;
	private TextField textField_2;
	private TextField textField_1;
	private TextField ackapatxt;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox_2;

	
	public void ekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmegirdileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO isletmegirdileri(mekantipi, kapasite, acikmasa, kapalimasa, sigara, alkol,acmakapama) VALUES (?,?,?,?,?,?,?)");
			
			uygula.setObject(1, comboBox.getSelectedItem().toString());
		    uygula.setString( 2,textField.getText() );
		    uygula.setString( 3,textField_1.getText() );
		    uygula.setString( 4,textField_2.getText() );
		 
			uygula.setObject(5, comboBox_1.getSelectedItem().toString());
			uygula.setObject(6, comboBox_2.getSelectedItem().toString());

				  
		    uygula.setString(7, ackapatxt.getText() );

		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					isletmebilgileri frame = new isletmebilgileri();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public isletmebilgileri() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextPane txtpnMekanBilgileri = new JTextPane();
		txtpnMekanBilgileri.setText("                \t    MEKAN B\u0130LG\u0130LER\u0130");
		txtpnMekanBilgileri.setForeground(Color.BLACK);
		txtpnMekanBilgileri.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 10));
		txtpnMekanBilgileri.setBackground(Color.LIGHT_GRAY);
		txtpnMekanBilgileri.setBounds(179, 41, 261, 25);
		contentPane.add(txtpnMekanBilgileri);
		
		MekanKapasitesikiiSays = new JMenuItem("Mekan Kapasitesi(Ki\u015Fi Say\u0131s\u0131)");
		MekanKapasitesikiiSays.setBounds(0, 163, 193, 22);
		contentPane.add(MekanKapasitesikiiSays);
		
		ToplamMasaSayskapal = new JMenuItem("Toplam Masa Sayısı");
		ToplamMasaSayskapal.setBounds(0, 223, 287, 22);
		contentPane.add(ToplamMasaSayskapal);
		
		TtnrnlerininSerbest = new JMenuItem("T\u00FCt\u00FCn \u00DCr\u00FCnlerinin Serbest Oldu\u011Fu Ortam");
		TtnrnlerininSerbest.setBounds(0, 281, 300, 22);
		contentPane.add(TtnrnlerininSerbest);
		
		
		
		
		AlkapanSaati = new JMenuItem("Acılıs-Kapanıs Saati");
		AlkapanSaati.setBounds(0, 395, 287, 22);
		contentPane.add(AlkapanSaati);
		
		textField = new TextField();
		textField.setText(" ");
		textField.setBounds(329, 162, 81, 23);
		contentPane.add(textField);
		
		textField_2 = new TextField();
		textField_2.setText(" ");
		textField_2.setBounds(444, 223, 81, 23);
		contentPane.add(textField_2);
		
		textField_1 = new TextField();
		textField_1.setText(" ");
		textField_1.setBounds(329, 222, 81, 23);
		contentPane.add(textField_1);
		
		ackapatxt = new TextField();
		ackapatxt.setText(" ");
		ackapatxt.setBounds(329, 394, 81, 23);
		contentPane.add(ackapatxt);
		
		JButton btnKaydet = new JButton("Kaydet");
		btnKaydet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bilgiguncelleTR frame = new bilgiguncelleTR();
				frame.setVisible(true);
		
				dispose();

			ekle();
			}
		});
		btnKaydet.setBounds(329, 508, 186, 41);
		contentPane.add(btnKaydet);
		
		AlkolKullanm = new JMenuItem("Alkol Tuketimi");
		AlkolKullanm.setBounds(0, 329, 300, 22);
		contentPane.add(AlkolKullanm);
		
		MekanTipi = new JMenuItem("Mekan Tipi");
		MekanTipi.setBounds(0, 116, 193, 22);
		contentPane.add(MekanTipi);
		
		JMenuItem mnıtmClosed = new JMenuItem("Kapalı\r\n");
		mnıtmClosed.setBounds(444, 195, 81, 22);
		contentPane.add(mnıtmClosed);
		
		JMenuItem mnıtmAck = new JMenuItem("Acık\r\n");
		mnıtmAck.setBounds(329, 194, 81, 22);
		contentPane.add(mnıtmAck);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Bar ", "Cafe", "Çay Bahçesi", "Gece Kulübü", "Pastane", "Restorant"}));
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboBox.setBounds(329, 116, 81, 20);
		contentPane.add(comboBox);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Var", "Yok"}));
		comboBox_1.setBounds(329, 283, 81, 20);
		contentPane.add(comboBox_1);
		
		comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Var", "Yok"}));
		comboBox_2.setBounds(329, 341, 81, 20);
		contentPane.add(comboBox_2);
	}
}
