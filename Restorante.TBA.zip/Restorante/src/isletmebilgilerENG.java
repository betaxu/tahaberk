import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JCheckBox;
import java.awt.TextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import org.w3c.dom.NameList;


public class isletmebilgilerENG extends JFrame {

	private JPanel contentPane;
	private TextField textField;
	private TextField textField_1;
	private TextField textField_2;
	private TextField textField_3;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox_2;

	
	
	public void ekle(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("driver hatası" + e);
		}
	Connection baglanti = null ;
	
	   try {
			baglanti= DriverManager.getConnection("jdbc:mysql://localhost:3306/isletmegirdileri","root","");
		} catch (Exception e) {
		   JOptionPane.showMessageDialog(null,"Baglantida hata olusti" +  e.getMessage());
		}
		
	   
	   
	   try {
		
			PreparedStatement uygula = baglanti.prepareStatement("INSERT INTO isletmegirdilerieng(mekantipi, kapasite, acikmasa, kapalimasa, sigara, alkol,acmakapama) VALUES (?,?,?,?,?,?,?)");
			
			uygula.setObject(1, comboBox.getSelectedItem().toString());
		    uygula.setString( 2,textField.getText() );
		    uygula.setString( 3,textField_1.getText() );
		    uygula.setString( 4,textField_2.getText() );
		 
			uygula.setObject(5, comboBox_1.getSelectedItem().toString());
			uygula.setObject(6, comboBox_2.getSelectedItem().toString());

				  
		    uygula.setString(7, textField_3.getText() );

		    
		    int Donut =uygula.executeUpdate();
		    if(Donut>0)JOptionPane.showMessageDialog(null, "Kayıt Başarıyla Eklendi");
		    else{
		    	JOptionPane.showMessageDialog(null, "Bir hata oluştu");
		    }
		} catch (Exception e) {
	    	JOptionPane.showMessageDialog(null, " TSQLde Bir hata oluştu" +e.getMessage());

		}
}	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					isletmebilgilerENG frame = new isletmebilgilerENG();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}



	public isletmebilgilerENG() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextPane txtpnMekanBilgileri = new JTextPane();
		txtpnMekanBilgileri.setText(" RESTAURANT INFORMATION");
		txtpnMekanBilgileri.setForeground(Color.BLACK);
		txtpnMekanBilgileri.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 10));
		txtpnMekanBilgileri.setBackground(Color.LIGHT_GRAY);
		txtpnMekanBilgileri.setBounds(220, 42, 159, 25);
		contentPane.add(txtpnMekanBilgileri);
		
		JMenuItem mnıtmMekanKapasitesikiiSays = new JMenuItem("PLACE CAPACITY(Number of Person)");
		mnıtmMekanKapasitesikiiSays.setBounds(0, 163, 248, 22);
		contentPane.add(mnıtmMekanKapasitesikiiSays);
		
		JMenuItem mnıtmToplamMasaSayskapal = new JMenuItem("TOTAL NUMBER OF DESKS(Closed Area - Open Area)");
		mnıtmToplamMasaSayskapal.setBounds(0, 223, 323, 22);
		contentPane.add(mnıtmToplamMasaSayskapal);
		
		JMenuItem mnıtmTtnrnlerininSerbest = new JMenuItem("Smoking Area");
		mnıtmTtnrnlerininSerbest.setBounds(0, 281, 269, 22);
		contentPane.add(mnıtmTtnrnlerininSerbest);
		
		
		
		
		JMenuItem mnıtmAlkapanSaati = new JMenuItem("Opening-Closing Time");
		mnıtmAlkapanSaati.setBounds(0, 395, 287, 22);
		contentPane.add(mnıtmAlkapanSaati);
		
		textField = new TextField();
		textField.setText(" ");
		textField.setBounds(329, 162, 81, 23);
		contentPane.add(textField);
		
		textField_1 = new TextField();
		textField_1.setText(" ");
		textField_1.setBounds(329, 222, 81, 23);
		contentPane.add(textField_1);
		
		textField_2 = new TextField();
		textField_2.setText(" ");
		textField_2.setBounds(434, 222, 81, 23);
		contentPane.add(textField_2);
		
		textField_3 = new TextField();
		textField_3.setText(" ");
		textField_3.setBounds(329, 394, 81, 23);
		contentPane.add(textField_3);
		
		JButton btnKaydet = new JButton("Save");
		btnKaydet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				
	    
				
				
				
				bilgiguncelleENG frame = new bilgiguncelleENG();
				frame.setVisible(true);
		
				dispose();

						 ekle( );

			}
		});
		btnKaydet.setBounds(434, 470, 89, 23);
		contentPane.add(btnKaydet);
		
		
		
		JMenuItem mnıtmAlkolKullanm = new JMenuItem("Alcohol Consuption");
		mnıtmAlkolKullanm.setBounds(0, 329, 255, 22);
		contentPane.add(mnıtmAlkolKullanm);
		
		JMenuItem mnıtmMekanTipi = new JMenuItem("PLACE TYPE");
		mnıtmMekanTipi.setBounds(0, 116, 193, 22);
		contentPane.add(mnıtmMekanTipi);
		
		comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Bar ", "Cafe", "\u00C7ay Bah\u00E7esi", "Gece Kul\u00FCb\u00FC", "Pastane", "Restorant"}));
		comboBox.setBounds(329, 118, 81, 20);
		contentPane.add(comboBox);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Available", "No"}));
		comboBox_1.setBounds(329, 283, 81, 20);
		contentPane.add(comboBox_1);
		
		comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Available", "No"}));
		comboBox_2.setBounds(331, 329, 81, 20);
		contentPane.add(comboBox_2);
	}
}
