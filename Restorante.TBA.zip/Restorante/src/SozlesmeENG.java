import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.Color;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.beans.Visibility;

public class SozlesmeENG extends JFrame {

	private JPanel contentPane;
	private final Action action = new SwingAction();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SozlesmeENG frame = new SozlesmeENG();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SozlesmeENG() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAccept = new JButton("Accept ");
		btnAccept.addComponentListener(new ComponentAdapter() {
			
		});
		
		btnAccept.setVisible(true);

		
		btnAccept.setBounds(426, 513, 142, 35);
		btnAccept.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				
			isletmecibilgileriENG frame  = new isletmecibilgileriENG();
			frame.setVisible(true);
		
			
			dispose();
			}
		});
		contentPane.add(btnAccept);
		
		JTextPane txtpnKullancSzlemesi = new JTextPane();
		txtpnKullancSzlemesi.setBackground(Color.GRAY);
		txtpnKullancSzlemesi.setText("kullan\u0131c\u0131 s\u00F6zle\u015Fmesi  \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t.            ");
		txtpnKullancSzlemesi.setBounds(32, 11, 534, 474);
		contentPane.add(txtpnKullancSzlemesi);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
